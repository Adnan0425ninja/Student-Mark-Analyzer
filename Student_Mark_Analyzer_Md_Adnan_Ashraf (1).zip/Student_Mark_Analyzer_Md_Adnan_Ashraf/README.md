# Student Mark Analyzer

**Project Owner:** Md Adnan Ashraf  
**Project Type:** Python Data Analysis  
**Tools:** Python, Pandas, NumPy, Matplotlib, Seaborn, Jupyter Notebook

## Overview
Student Mark Analyzer is a beginner-friendly data analysis project that reads student marks from a CSV file, calculates totals and averages, assigns grades, checks pass/fail status, and visualizes class performance.

## Features
- Reads student records from `data/student_marks.csv`
- Calculates total and average marks for each student
- Determines pass/fail status (minimum 40 in every subject)
- Assigns grades from F to A+
- Displays class statistics and the top five students
- Generates charts for subject averages, pass/fail distribution, grade distribution, and top students
- Exports the analyzed results to a CSV file

## Project Structure
```text
Student_Mark_Analyzer_Md_Adnan_Ashraf/
├── data/
│   └── student_marks.csv
├── notebooks/
│   └── Student_Mark_Analyzer.ipynb
├── reports/
│   ├── Project_Report.md
│   └── Project_Report.pdf
├── src/
│   └── student_mark_analyzer.py
├── requirements.txt
└── README.md
```

## Dataset
The included dataset is **synthetic sample data** created for demonstration and learning. It contains 40 fictional student records and marks in Mathematics, Programming, and Physics. Replace it with authorized class data if your instructor requires real data.

## Run in Google Colab
1. Download and extract this project ZIP.
2. Open [Google Colab](https://colab.research.google.com/).
3. Upload `notebooks/Student_Mark_Analyzer.ipynb`.
4. Upload `data/student_marks.csv` when the notebook asks for it, or keep the CSV in the same folder if running locally.
5. Run all notebook cells from top to bottom.

## Run Locally
```bash
# 1. Create and activate a virtual environment (optional)
python -m venv .venv

# macOS/Linux
source .venv/bin/activate

# Windows
.venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the analyzer
python src/student_mark_analyzer.py
```

## Grading Rules
| Average Marks | Grade |
|---:|:---:|
| 90–100 | A+ |
| 80–89.99 | A |
| 70–79.99 | B |
| 60–69.99 | C |
| 50–59.99 | D |
| Below 50 | F |

A student passes only when they score at least 40 in **each** subject.

## Technologies Used
- **Pandas:** reading, cleaning, and summarizing tabular data
- **NumPy:** numerical calculations and pass/fail logic
- **Matplotlib / Seaborn:** charts and visualizations
- **Jupyter Notebook:** interactive project workflow

## Author
**Md Adnan Ashraf**

## Note
This is an educational project. The sample names and marks are fictional and should not be treated as actual academic records.
