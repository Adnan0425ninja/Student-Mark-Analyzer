"""
Student Mark Analyzer
Project owner: Md Adnan Ashraf

Analyze student marks using Pandas, NumPy, Matplotlib and Seaborn.
Run: python src/student_mark_analyzer.py
"""
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

ROOT = Path(__file__).resolve().parents[1]
DATA_FILE = ROOT / "data" / "student_marks.csv"
OUTPUT_DIR = ROOT / "reports" / "charts"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

SUBJECTS = ["Mathematics", "Programming", "Physics"]
PASS_MARK = 40

def load_data(path=DATA_FILE):
    """Load the CSV file and validate required columns."""
    data = pd.read_csv(path)
    required = ["Student_ID", "Student_Name", *SUBJECTS]
    missing = [col for col in required if col not in data.columns]
    if missing:
        raise ValueError(f"Dataset is missing required columns: {missing}")
    return data

def prepare_data(data):
    """Calculate totals, averages, result and grade from subject marks."""
    data = data.copy()
    for subject in SUBJECTS:
        data[subject] = pd.to_numeric(data[subject], errors="coerce")
    if data[SUBJECTS].isna().any().any():
        raise ValueError("Subject marks contain missing or non-numeric values.")
    if ((data[SUBJECTS] < 0) | (data[SUBJECTS] > 100)).any().any():
        raise ValueError("Marks must be between 0 and 100.")
    data["Total_Marks"] = data[SUBJECTS].sum(axis=1)
    data["Average_Marks"] = data[SUBJECTS].mean(axis=1).round(2)
    data["Result"] = np.where(data[SUBJECTS].min(axis=1) >= PASS_MARK, "Pass", "Fail")
    data["Grade"] = pd.cut(
        data["Average_Marks"],
        bins=[-0.01, 49.99, 59.99, 69.99, 79.99, 89.99, 100],
        labels=["F", "D", "C", "B", "A", "A+"]
    ).astype(str)
    return data

def print_summary(data):
    """Print useful class-level statistics."""
    print("\\n========== STUDENT MARK ANALYZER ==========")
    print(f"Project owner: Md Adnan Ashraf")
    print(f"Number of students : {len(data)}")
    print(f"Class average      : {data['Average_Marks'].mean():.2f}")
    print(f"Highest average    : {data['Average_Marks'].max():.2f}")
    print(f"Lowest average     : {data['Average_Marks'].min():.2f}")
    print(f"Pass count         : {(data['Result'] == 'Pass').sum()}")
    print(f"Fail count         : {(data['Result'] == 'Fail').sum()}")
    print(f"Pass percentage    : {(data['Result'].eq('Pass').mean() * 100):.1f}%")
    print("\\nSubject averages:")
    print(data[SUBJECTS].mean().round(2).to_string())
    print("\\nTop 5 students:")
    print(data.nlargest(5, "Average_Marks")[["Student_Name", "Total_Marks", "Average_Marks", "Grade"]].to_string(index=False))

def create_charts(data):
    """Save subject, grade, result and student-comparison charts."""
    sns.set_theme(style="whitegrid")
    # Average marks by subject
    plt.figure(figsize=(8, 5))
    data[SUBJECTS].mean().plot(kind="bar")
    plt.title("Average Marks by Subject")
    plt.ylabel("Average marks (out of 100)")
    plt.ylim(0, 100)
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "subject_averages.png", dpi=150)
    plt.close()

    # Pass/fail distribution
    plt.figure(figsize=(6, 5))
    data["Result"].value_counts().reindex(["Pass", "Fail"], fill_value=0).plot(
        kind="pie", autopct="%1.1f%%", startangle=90
    )
    plt.title("Pass / Fail Distribution")
    plt.ylabel("")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "pass_fail_distribution.png", dpi=150)
    plt.close()

    # Grade distribution
    plt.figure(figsize=(8, 5))
    order = ["F", "D", "C", "B", "A", "A+"]
    data["Grade"].value_counts().reindex(order, fill_value=0).plot(kind="bar")
    plt.title("Grade Distribution")
    plt.xlabel("Grade")
    plt.ylabel("Number of students")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "grade_distribution.png", dpi=150)
    plt.close()

    # Top ten students
    top = data.nlargest(10, "Average_Marks").sort_values("Average_Marks")
    plt.figure(figsize=(9, 6))
    top.plot.barh(x="Student_Name", y="Average_Marks", legend=False)
    plt.title("Top 10 Students by Average Marks")
    plt.xlabel("Average marks")
    plt.xlim(0, 100)
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "top_students.png", dpi=150)
    plt.close()
    print(f"Charts saved in: {OUTPUT_DIR}")

def main():
    data = prepare_data(load_data())
    print_summary(data)
    data.to_csv(ROOT / "reports" / "analyzed_student_results.csv", index=False)
    create_charts(data)
    print("\\nAnalyzed results saved to reports/analyzed_student_results.csv")

if __name__ == "__main__":
    main()
