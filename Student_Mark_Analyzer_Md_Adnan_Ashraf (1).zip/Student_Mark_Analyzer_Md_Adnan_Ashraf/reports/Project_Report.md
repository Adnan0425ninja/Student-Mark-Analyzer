# Student Mark Analyzer — Project Report

**Project Owner:** Md Adnan Ashraf  
**Project Domain:** Data Analysis using Python

## 1. Abstract
Student Mark Analyzer is a Python-based data analysis project that processes student marks and presents meaningful academic summaries. It uses Pandas and NumPy for data processing and Matplotlib/Seaborn for visual representation.

## 2. Objectives
- Store and read student marks in CSV format.
- Calculate each student's total and average marks.
- Determine pass/fail status using a minimum subject mark of 40.
- Assign a grade based on average marks.
- Identify high-performing students and compare subject performance.
- Present the findings through charts and a summarized output file.

## 3. Tools and Technologies
| Tool | Purpose |
|---|---|
| Python | Main programming language |
| Pandas | CSV handling and tabular analysis |
| NumPy | Numerical calculations |
| Matplotlib | Data visualization |
| Seaborn | Statistical charts |
| Jupyter Notebook / Google Colab | Interactive execution |

## 4. Dataset Description
The supplied CSV contains 40 fictional student records. Each record includes a student ID, student name, class, marks in Mathematics, Programming and Physics, total marks, average marks, result and grade. Each subject is marked out of 100.

**Data note:** This is synthetic demonstration data, not real student information.

## 5. Methodology
1. Import the required Python libraries.
2. Read the CSV dataset using Pandas.
3. Validate that required columns exist and marks are numeric and between 0 and 100.
4. Calculate total and average marks.
5. Mark a student as Pass only if every subject mark is at least 40; otherwise mark Fail.
6. Assign grades using the average-mark scale.
7. Calculate class-level statistics and rank students by average.
8. Generate charts and export the analyzed results.

## 6. Grading Criteria
| Average | Grade |
|---:|:---:|
| 90–100 | A+ |
| 80–89.99 | A |
| 70–79.99 | B |
| 60–69.99 | C |
| 50–59.99 | D |
| Below 50 | F |

## 7. Results and Analysis
The project computes the class average, highest and lowest student averages, pass count, fail count, pass percentage, subject-wise averages and top-five student list at runtime. It also creates:
- `subject_averages.png`
- `pass_fail_distribution.png`
- `grade_distribution.png`
- `top_students.png`

The exact numerical results are generated from the CSV when the notebook or Python script is executed.

## 8. Conclusion
The Student Mark Analyzer demonstrates how Python libraries can turn a simple marks spreadsheet into useful academic information. It reduces repetitive manual calculations and makes class performance easier to understand through summaries and charts.

## 9. Future Scope
- Add a graphical user interface or web dashboard.
- Support more subjects and multiple classes.
- Add student-wise PDF report cards.
- Import Excel files and validate duplicate student IDs.
- Add filters for class, subject and grade.

## 10. Author
**Md Adnan Ashraf**
